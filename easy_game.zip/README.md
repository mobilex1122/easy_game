# easy_game
 need for run:
 pip install pygame

 controls:
 left
 right

 if you lose press space to continue
